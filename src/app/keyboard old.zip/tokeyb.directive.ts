import { Directive, ElementRef, HostListener, Input, OnInit, Renderer2 } from '@angular/core';
import { GDataService } from '../svc/gdata.service';


@Directive({
  selector: '[tokeyb]'
})
export class TokeybDirective implements OnInit{
  


  constructor(private hostElt: ElementRef,
    public renderer: Renderer2,
   
    private gdata:GDataService//,
    //private renderer: Renderer2,
     ) {

  }
    @Input() tobeToggledClassName?: string;
    @HostListener("focus")
    attachKeyboard(){
      const trgOld = this.gdata.Target;
      this._detachKeyboard(trgOld)
      const trg = this.hostElt.nativeElement;
      console.log(`@attach: ${this._id} value:"${trg.value}"` );
 
      trg.classList.add('my-border');


    }
    private _detachKeyboard(trgOld: any | null){
    if(trgOld && trgOld.classList){
      trgOld.classList.remove('my-border');
      if(trgOld.id){
        console.log(`@detach: ${trgOld.id} value:"${trgOld.value}"` );

      }
     
    }
  }

    @HostListener("blur")
    detachKeyboard( ){
    //  console.log(`@detach: ${this._id} value:"${(evt.target as any).value}"` );
    
      //b vthis.hostElt.nativeElement.classList.remove('my-border');
 
     }
 
     _id:string = '';
     ngOnInit(): void {
       this._id = this.hostElt.nativeElement.id;
 
       console.log('@Init:'+ this._id);
       //this.hostElt.nativeElement.
     }

}
