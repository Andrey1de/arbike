import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
const keyLayoutEn : string[][] = [
  [    "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "@", "/", "backspace"],
  [    "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "?", "?"],
  [    "a", "s", "d", "f", "g", "h", "j", "k", "l", "?", "?", "?", "?", "done"],
  [    "z", "x", "c", "v", "b", "n", "m", "?", "?", "?", ",", ".", "?", "?"],
["caps","space", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?"]
];

const keyLayoutHe : string[][] = [
  [    "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "@", "/", "backspace"],
  [    "'", "ק", "ר", "א", "ט", "ו", "ן", "ם", "פ", "?", "?", "?", "?", "?"],
  [    "ש", "ד", "ג", "כ", "ע", "י", "ח", "ל", "ך", "ף", "?", "?","?", "done"],
  [    "ז", "ס", "ב", "ה", "נ", "מ", "צ", "ת", "ץ","\\",",", ".", "?", "?"],
  [    "caps","space", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?",  "?", "?" ]


];

const keyLayoutRu : string[][]= [
  [    "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "@", "/", "backspace"],
  [    "й", "ц", "у", "к", "е", "н", "г", "ш", "щ", "з", "х", "э", "?", "?"],
  [    "ф", "ы", "в", "а", "п", "р", "о", "л", "д", "ж", "?", "ъ", "?", "done"],
  [    "я", "ч", "с", "м", "и", "т", "ь", "б", "ю", ",", ".", "?", "?", "?"],
  [   "caps", "space", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?"]

];

const keyLayoutAr : string[][]= [
  [    "1", "2", "3", "4", "5", "6", "7",  "8", "9", "0", "-", "@",  "/", "backspace"],
  [    "ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د",  "لإ", "إ"],
  [    "ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط", "لأ",  "أ", "done"],
  [    "ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "لآ", "آ", "\\", ",", "." ],
  [    "caps","space", "?", "?", "?", "?",  "?", "?", "?", "?", "?", "?",  "?" ]

];

export function globalGetKeyId(row:number,col:number){
  return `ikbd-${row}-${('00' + col)}`;
}
export function creatorKeyModel(row:number,col:number){

  const strId = globalGetKeyId(row,col);
  let ret  = mapModules.get(strId) ;
  if(!ret){
      ret = new KeyboardKeyModel(row,col);
      mapModules.set(strId,ret);

  }
  return ret;

}

const mapModules: Map<string,KeyboardKeyModel> =  
  new Map<string,KeyboardKeyModel>();

export function globalGetKeyLayout(lan:string): string[][]{
  lan = lan.toLocaleLowerCase().substring(0,2);
  switch (lan) {
    case 'ru': return keyLayoutRu;
    case 'ar': return keyLayoutAr;
    case 'he': return keyLayoutHe;
  
  }
  return keyLayoutEn;
}



export function globalSetLanguage(lan: string){
  KeyboardControllerService.Language = lan;
}

export function globalGetLanguage() : string{
  return KeyboardControllerService.Language;
}
export function globalLanguage$() : 
BehaviorSubject<string>
{
  return KeyboardControllerService.Language$;
}
@Injectable({
  providedIn: 'root'
})
export class KeyboardControllerService { 
  
   public static  readonly Language$ : BehaviorSubject<string> = 
    new BehaviorSubject<string>('en');
    static get  Language() : string {
        return KeyboardControllerService.Language$.value;
    } 
    static set  Language(lan: string){
      if(lan == 'en' || lan == 'ru' ||  lan == 'he' ||  lan == 'ar'){
        if(lan != KeyboardControllerService.Language$.value){
          KeyboardControllerService.Language$.next(lan)
        }
      }
      
    }


  constructor() { }
}


export class KeyboardKeyModel{

  public Key:string = '';
  static globalIsUpper: boolean = false;
  btnText:string ='';
  isHaveUpper:boolean = false; 
  isAlfa:boolean = false;
  readonly id!:string;

  constructor( readonly Row:number,readonly Col:number,){
      this.id = globalGetKeyId(this.Row,this.Col);
      this.setMe();
  }

  setMe(lang:string){
          //let lang = globalGetLanguage();

          this.Key = '' +  globalGetKeyLayout(lang);
          const _key  = this.Key.toLowerCase();

    
          this.isAlfa = !!_key && (_key.length === 1 || 
                  (lang == 'ar' && _key.length === 2)) ;
          this.isHaveUpper = (_key >= 'a' && _key <= 'z')
                   && (_key >= 'а' && _key <= 'я');
          
          if(this.isAlfa) {
              this.btnText = (this.isHaveUpper && KeyboardKeyModel.globalIsUpper) ? _key.toUpperCase() :
              _key;
          } else {

              this.btnText = '';
          
          }            
               

  }

}
   