import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { KeyboardKeyModel, creatorKeyModel } from '../keyboard.controller.service';



const keyLayoutEn : string[][] = [
  [    "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "@", "/", "backspace"],
  [    "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "?", "?"],
  [    "a", "s", "d", "f", "g", "h", "j", "k", "l", "?", "?", "?", "?", "done"],
  [    "z", "x", "c", "v", "b", "n", "m", "?", "?", "?", ",", ".", "?", "?"],
["caps","space", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?"]
];

const keyLayoutHe : string[][] = [
  [    "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "@", "/", "backspace"],
  [    "'", "ק", "ר", "א", "ט", "ו", "ן", "ם", "פ", "?", "?", "?", "?", "?"],
  [    "ש", "ד", "ג", "כ", "ע", "י", "ח", "ל", "ך", "ף", "?", "?","?", "done"],
  [    "ז", "ס", "ב", "ה", "נ", "מ", "צ", "ת", "ץ","\\",",", ".", "?", "?"],
  [ "?","space", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?",  "?", "?" ]


];

const keyLayoutRu : string[][]= [
  [    "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "@", "/", "backspace"],
  [    "й", "ц", "у", "к", "е", "н", "г", "ш", "щ", "з", "х", "э", "?", "?"],
  [    "ф", "ы", "в", "а", "п", "р", "о", "л", "д", "ж", "?", "ъ", "?", "done"],
  [    "я", "ч", "с", "м", "и", "т", "ь", "б", "ю", ",", ".", "?", "?", "?"],
["caps", "space", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?"]

];

const keyLayoutAr : string[][]= [
  [    "1", "2", "3", "4", "5", "6", "7",  "8", "9", "0", "-", "@",  "/", "backspace"],
  [    "ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د",  "لإ", "إ"],
  [    "ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط", "لأ",  "أ", "done"],
  [    "ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "لآ", "آ", "\\", ",", "." ],
  [ "?","space", "?", "?", "?", "?",  "?", "?", "?", "?", "?", "?",  "?" ]

];

export function GetKeyLayout(lan:string): string[][]{
  lan = lan.toLocaleLowerCase().substring(0,2);
  switch (lan) {
    case 'ru': return keyLayoutRu;
    case 'ar': return keyLayoutAr;
    case 'he': return keyLayoutHe;
  
  }
  return keyLayoutEn;
}

enum eKeyWidth{
  normal,
  wide,
  extra


}


@Component({
  selector: 'keyboard-key',
  templateUrl: './keyboard-key.component.html',
  styleUrls: ['./keyboard-key.component.scss']
})
export class KeyboardKeyComponent implements OnInit, AfterViewInit{
 
 
  @Input('lang') Lang: string = 'en';

  @Input('key-row') keyRow: number = -1;
  
  @Input('key-col') keyCol: number = -1;
  public isCaps:boolean = false;
  public get keyCaps():boolean {return KeyboardKeyComponent.staticCaps;}

  @Input('key') public key: string ='';
  static staticCaps:boolean = false;

  m!:KeyboardKeyModel;
   
  constructor()
  {

  }
  keyId!:string;
 
  public isDigit:boolean = false;
  public isAlfa: boolean = false;
  public keyIcon:string = '';

  ngOnInit(): void {
    this.isCaps = KeyboardKeyComponent.staticCaps;
    this.m = creatorKeyModel(this.keyRow,this.keyCol);
    
    this.m.setMe(this.Lang);
    console.log("KeyboardKeyComponent.OnInit",this.keyRow ,this.keyCol)
  }

  // inputClasses: string[] = ["keyboard__key"];
  // iconClasses: string[] = ["material-icons"];
  // // setCaps(){
  //   if(this.keyCaps)

  // }

  // _setButtonAndIcon() {
  //   this.key = this.key.toLowerCase();
  //   if(this.key.length === 1){
  //     this.isDigit = '01234567890.,/\\?@-+'.lastIndexOf(this.key) != -1;
  //   }
    
  //   if(this.isDigit) return;

  //   switch (this.key) {
  //     case "backspace":
  //       this.keyIcon = "backspace";
  //       this.inputClasses.push("keyboard__key--wide");
  //       break;
  //     case "caps":
  //       this.keyIcon = "keyboard_capslock";
  //       this.inputClasses.push("keyboard__key--wide");
  //       this.iconClasses.push("keyboard__key--activatable");
       

  //       break;
  //     case "space":
  //       this.keyIcon = "space_bar";
  //       this.inputClasses.push("keyboard__key--extra-wide");

  //       break;
  //     case "done":
  //       this.keyIcon = "check";
  //       this.inputClasses.push("keyboard__key--wide");
  //       this.iconClasses.push("keyboard__key--icon-done")

  //       break;
              
  //     default:
  //       if(this.key.length == 1 || this.key.length == 2 ){
  //         this.isAlfa = true;
  //       }

  //       break;
  //     }
     
  // }
  setCaps(event:any){
    this.isCaps = !this.isCaps ;
    KeyboardKeyComponent.staticCaps = this.isCaps;
  }
  ngAfterViewInit(): void {

   
  }

  _
}
.
